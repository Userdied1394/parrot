<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

# 𝐏𝐘𝐑𝐎 𝐑𝐄𝐍𝐀𝐌𝐄 𝐁𝐎𝐓


<p align="center"> 🅡🅔🅟🅞 🅢🅣🅐🅣🅢 </p>


![github card](https://github-readme-stats.vercel.app/api/pin/?username=TEAM-PYRO-BOTZ&repo=PYRO-RENAME-BOT&theme=dark)


### Sᴀᴍᴩʟᴇ Bᴏᴛ (Official Pyro Rename Bot)

<p align="center">
🤖 <a href="https://t.me/Pyro_Rename_Bot"><img title="Telegram" src="https://img.shields.io/static/v1?label=PYRO+RENAME&message=BOT&color=blue-green"></a> 🤖
</p>


## Deploy To Koyeb

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/TEAM-PYRO-BOTZ/PYRO-RENAME-BOT&env[BOT_TOKEN]&env[API_ID]&env[API_HASH]&env[WEBHOOK]=True&env[ADMIN]&env[DB_URL]&env[DB_NAME]=pyro-botz&env[FORCE_SUB]&env[START_PIC]&env[LOG_CHANNEL]=You%20Dont%20Need%20LogChannel%20To%20Remove%20This%20Variable&run_command=python%20bot.py&branch=main&name=pyro-rename) 

## Deploy To Render

◉ Watch Tutorial For Render Deploy <a href="https://graph.org/file/3c0171b4d2d72a2018a18.jpg"><img src="https://img.shields.io/badge/Watch%20Tutorial%20On%20YouTube-red.svg?logo=Youtube"></a>                     

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/TEAM-PYRO-BOTZ/PYRO-RENAME-BOT)

## Deploy To Railway

<a href="https://graph.org/file/fabd75cd5043d2cfdc13d.jpg"><img src="https://railway.app/button.svg" alt="Deploy"></a>

## Deploy To Heroku

<a href="https://heroku.com/deploy?template=https://github.com/TEAM-PYRO-BOTZ/PYRO-RENAME-BOT"><img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy"></a>



## Configs 

* `BOT_TOKEN`  - Get Bot Token From @BotFather

* `API_ID` - From my.telegram.org 

* `API_HASH` - From my.telegram.org

* `WEBHOOK` - If Your Server Is Need Web Service! Value = `True` Else Value = `False`

* `ADMIN` - AUTH Or Bot Controllers Id's Multiple Id Use Space To Split 

* `DB_URL`  - Mongo Database URL From https://cloud.mongodb.com

* `DB_NAME`  - Your Database Name From Mongodb. 

* `FORCE_SUB` - Your Force Sub Channel Username Without @

* `LOG_CHANNEL` - Bot Logs Sending Channel. If You Don't Need This To Remove This Variable In Your Server

* `START_PIC` - Start Message Photo. You Don't Need This! Just Skip

## Botfather Commands
```
start - Bot Alive Cheking
view_thumb - View Thumbnail
del_thumb - Delete Thumbnail
set_caption - Set A Custom Caption
see_caption - See Your Custom Caption
del_caption - Delete Custom Caption
restart - To Rrstart The Bot (Admin Only)
status - Check Bot Status (Admin Only)
broadcast - Send Message To All Users (Admin Only)
```

## ❣️Thanks To

<a href="https://t.me/lntechnical">
   <p> lntechnical TG</p>
  </a>
<a href="https://youtube.com/c/LNtechnical">
   <p> lntechnical YT </p>
  </a>

## 🤩 INSPIRATION

<a href="https://youtube.com/c/MoTech_YT">
   <p>❣️ MoTech 🔥</p>
  </a>



